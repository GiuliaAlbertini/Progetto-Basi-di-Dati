package data;

import java.sql.Connection;

import java.time.Year;

public class Nomine {
    
    private Year anno;
    private String nomeCarica;
    private String nomeCircolo;

}
