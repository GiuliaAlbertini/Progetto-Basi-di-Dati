package data;

public class Posizionamenti {
    
    private String nomeCategoria;
    private int posizione;
    private int punteggio;

}
